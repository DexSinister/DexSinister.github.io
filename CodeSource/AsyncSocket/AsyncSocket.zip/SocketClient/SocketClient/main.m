//
//  main.m
//  SocketClient
//
//  Created by 000 on 15/8/31.
//  Copyright (c) 2015年 000. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
